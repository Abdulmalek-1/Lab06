#include <stdio.h>

int main(){
    
    int *ptr1;
    if( sizeof(ptr1) * 8 == 64 ){
        printf("The system is 64 bit architecture\n");
    } else {
        printf("The system is 32 bit architecture\n");
    }
    int number = 1;
    char *ptr2 = (char*)&number;
    if(*ptr2 == 1){
        printf("The system is Little Endian\n");
    } else {
        printf("The system is Big Endian\n");
    }
    
    return 0;
}
