#include <stdio.h>

int main(){
    
    int intArray[4];
    char charArray[4];
    short shortArray[4];
    double doubleArray[4];
    printf("Integer Array:\n");
    for(int i = 0; i < 4; i++){
        printf("\t%p\n", &intArray[i]);
    }
    printf("\nCharacter Array:\n");
    for(int i = 0; i < 4; i++){
        printf("\t%p\n", &charArray[i]);
    }
    printf("\nShort Array:\n");
    for(int i = 0; i < 4; i++){
        printf("\t%p\n", &shortArray[i]);
    }
    printf("\nDouble Array:\n");
    for(int i = 0; i < 4; i++){
        printf("\t%p\n", &doubleArray[i]);
    }
    

    return 0;
}
