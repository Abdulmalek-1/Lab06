#include <stdio.h>
#include <ctype.h>
int StringLength(char sentence[]);
int NumOfWords(char sentence[], int StrLength);
int NumOfVowels(char sentence[], int StrLength);
void VowelFreq (char sentence[]);

int main(){
        char string[100];
        printf("Enter a string: ");
        scanf("%[^\n]s", string);
        printf("String length: %d\n", StringLength(string));
        printf("Number of words: %d\n", NumOfWords(string, StringLength(string)));
        printf("Number of vowels: %d\n", NumOfVowels(string, StringLength(string)));
        printf("Frequency of the vowels: \n");  VowelFreq(string);
        return 0;
}


int StringLength(char sentence[]){
        int count = 0;
        while(*sentence != '\0'){
                count++;
                sentence++;
        }
        return count;
        /*another shorter way:
          return (int)sizeof(sentence) / sizeof(char);
        */
}
int NumOfWords(char sentence[], int StrLength){
        int count = 0;
        for(int i = 0; i <= StrLength; i++){
                if(sentence[i] == ' '){
                        count++;
                }
        }
        return count+1;
}
int NumOfVowels(char sentence[], int StrLength){
        int count = 0;
        for(int i = 0; i <= StrLength; i++){
                if(toupper(sentence[i]) == 'A' || toupper(sentence[i]) == 'E' || toupper(sentence[i]) == 'I' ||
                   toupper(sentence[i]) == 'O' || toupper(sentence[i]) == 'U'){
                        count++;
                }
        }
        return count;
}
void VowelFreq (char sentence[]){
        int Acount = 0;
        int Ecount = 0; 
        int Icount = 0;
        int Ocount = 0;
        int Ucount = 0;
        
        for(int i = 0; i <= StringLength(sentence); i++){
                switch(toupper(sentence[i])){
                    case 'A': Acount++; break;
                    case 'E': Ecount++; break;
                    case 'I': Icount++; break;
                    case 'O': Ocount++; break;
                    case 'U': Ucount++; break;
                }
        }
        printf("A ==> %d\n", Acount);
        printf("E ==> %d\n", Ecount);
        printf("I ==> %d\n", Icount);
        printf("O ==> %d\n", Ocount);
        printf("U ==> %d\n", Ucount);
}

