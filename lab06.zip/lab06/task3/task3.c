#include <stdio.h>

int addInt(int n1, int n2);
float addFloat(float n1, float n2);
float areaCircle(float r);
float areaRectangle(float w, float l);
int factorial(int n);

int main(){
    printf("Addition of any two integer numbers: %d\n", addInt(5,5));
    printf("Addition of any two floating point numbers: %.2f\n", addFloat(5.5,5.5));
    printf("Calculation of area of circle: %.2f\n", areaCircle(2.0));
    printf("Calculation of area of rectangle: %.2f\n", areaRectangle(5.0,5.0));
    printf("Calculation of factorial of a number: %d\n", factorial(5));
    
    
    return 0;
}

int addInt(int n1, int n2){
    return n1+n2;
}
float addFloat(float n1, float n2){
    return n1+n2;
}
float areaRectangle(float w, float l){
    return w*l;
}
float areaCircle(float r){
    return 3.14 * (r*r);
}
int factorial(int n){
    /* using recursion:
    if( n <= 1){
        return 1;
    } 
    return n * factorial(n-1);
    */
    // using loop
    int product = 1;
    for(int i = 1; i <= n; i++){
        product *= i;
    }
    return product;
}

