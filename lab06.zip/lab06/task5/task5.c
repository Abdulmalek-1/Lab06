#include <stdio.h>

void MatrixVectorMultiplication(int row, int col, int X[], int A[][col]);

int main() {
    printf("Enter the A matrix row:");
    int row;
    scanf("%d", &row);
    
    printf("Enter the A matrix col:");
    int col;
    scanf("%d", &col);

    int A[row][col];
    printf("Enter the A matrix:\n");
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            printf("[%d][%d] => ", i + 1, j + 1);
            scanf("%d", &A[i][j]);
        }
    }

    int X[row];
    printf("Enter the X vector:\n");
    for (int i = 0; i < row; i++) {
        printf("[%d] => ", i + 1);
        scanf("%d", &X[i]);
    }

    MatrixVectorMultiplication(row, col, X, A);

    return 0;
}

void MatrixVectorMultiplication(int row, int col, int X[], int A[][col]) {
    int Y[row];

    for (int i = 0; i < row; i++) {
        Y[i] = 0;
    }

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            Y[i] += X[i] * A[i][j];
        }
    }

    printf("\nThe result: \n");
    printf("Matrix A:\n");
    for (int i = 0; i < row; i++) {
        printf("|");
        for (int j = 0; j < col; j++) {
            printf(" %d ", A[i][j]);
        }
        printf("|\n");
    }

    printf("Vector X:\n");
    for (int i = 0; i < row; i++) {
        printf("| %d |\n", X[i]);
    }

    printf("Result Vector Y:\n");
    for (int i = 0; i < row; i++) {
        printf("| %d |\n", Y[i]);
    }
}
